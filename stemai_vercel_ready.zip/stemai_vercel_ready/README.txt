stemAI website

Upload this whole folder to Vercel, or upload the index.html file inside it.
The website file is: index.html
